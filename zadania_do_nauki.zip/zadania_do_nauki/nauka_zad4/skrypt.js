let n = prompt("Podaj liczbę końcową:");
n = parseInt(n);
let suma = 0;
for (let i = 0; i<= n; i++) {
    suma += i;
}
document.write(suma);