# Zadanie 5 (Nauka): Pętla i IF - Liczby Parzyste

Często w pętli nie chcemy robić wszystkiego dla każdego elementu, ale tylko dla wybranych. Tu pomoże nam instrukcja `if`.

## Cel

Wypisać wszystkie liczby parzyste z zakresu od 0 do 20.

## Instrukcja krok po kroku

1.  Stwórz zwykłą pętlę `for` działającą od 0 do 20.
2.  Wewnątrz pętli nie wypisuj od razu liczby `i`. Najpierw sprawdź warunek.
3.  Liczba jest parzysta, gdy dzieli się przez 2 bez reszty. W informatyce resztę z dzielenia liczy operator `%` (modulo).
    - Warunek: `if (i % 2 == 0)`
4.  Wewnątrz bloku `if` wpisz instrukcję `document.write(i + " ... ");`.
5.  Dzięki temu liczby nieparzyste (np. 1, 3, 5) zostaną pominięte (bo dla nich `i % 2` wynosi 1, a nie 0).

## Czego się nauczyłeś?

- Jak łączyć pętle z instrukcjami warunkowymi, aby filtrować dane.
- Działania operatora `%` (modulo).
