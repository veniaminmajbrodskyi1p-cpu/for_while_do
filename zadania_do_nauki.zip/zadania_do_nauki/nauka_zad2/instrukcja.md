# Zadanie 2 (Nauka): Pętla WHILE - Odliczanie

To zadanie nauczy Cię, jak używać pętli `while`. Jest ona przydatna, gdy warunek jest ważniejszy niż liczba powtórzeń (choć tu użyjemy jej jak licznika).

## Cel

Wypisać odliczanie od 10 do 0 (10, 9, 8... 0) i na końcu napis "START!".

## Instrukcja krok po kroku

1.  Otwórz plik `skrypt.js`.
2.  Stwórz zmienną pomocniczą (licznik) przed pętlą.
    ```javascript
    let licznik = 10;
    ```
3.  Zapisz pętlę `while`. Warunek w nawiasie ma sprawdzać, czy `licznik` jest większy lub równy 0.
    ```javascript
    while (licznik >= 0) {
      // Kod wewnątrz pętli
    }
    ```
4.  Wewnątrz pętli:
    - Wypisz aktualną wartość licznika (`document.write` + przecinek i spacja).
    - **Bardzo ważne:** Zmniejsz licznik o 1! Inaczej pętla będzie działać w nieskończoność.
    ```javascript
    licznik--; // to samo co licznik = licznik - 1;
    ```
5.  Po zamknięciu klamry pętli `}`, dodaj kod wypisujący "START!". Wykona się on dopiero gdy pętla skończy działanie.
6.  Przetestuj kod.

## Czego się nauczyłeś?

- Jak działa pętla `while` (sprawdź warunek -> wykonaj -> sprawdź warunek...).
- Że musisz pamiętać o ręcznej zmianie zmiennej sterującej wewnątrz `while` (np. `licznik--`).
