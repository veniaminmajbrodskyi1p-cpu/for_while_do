let licznik = 10;
while (licznik >= 0) {
document.write(licznik ,", ");
licznik = licznik - 1;
}
document.write("start");
