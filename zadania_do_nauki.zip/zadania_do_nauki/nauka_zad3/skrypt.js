let haslo;
do {
    haslo = prompt("Podaj hasło (spróbuj wpisać 'tajne'):");
} while (haslo != "tajne");
`alert("Brawo! Hasło poprawne.");`